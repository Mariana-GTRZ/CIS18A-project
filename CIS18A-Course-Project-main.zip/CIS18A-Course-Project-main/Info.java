// Info.java is the interface used in UserInfo class to gather basic user information
interface Info {
    void getInfo();
   void getDate();
   void WriteSummary();
   void ReadSummary();
}
