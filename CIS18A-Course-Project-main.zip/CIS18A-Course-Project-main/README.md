# CIS18A-Course-Project
Community Garden Program
The Communtiy Garden program is a program for a user to be able to create an appointment to a public garden. The program also allows users to donate supplies which are saved into a file. The pprogram allows users to donate money and offer volunteering time which are also saved into a file. The program outputs a final summary on the user's information and the offerings they input in the program. 
